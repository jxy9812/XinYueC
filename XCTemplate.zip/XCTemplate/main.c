﻿#include"XString.h"
#include<stdio.h>
int main()
{
	XString* str = XString_create_fmt_utf8("你好");

	printf("%s\n",XString_c_str(str));
	XString_delete_base(str);
}