﻿#include"XString.h"
#include<stdio.h>
int main()
{
	XString* str = XString_create_fmt("你好");

	printf("%s\n",XString_c_str(str));
	XString_delete_base(str);
}